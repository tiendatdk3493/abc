package com.tma.gbst.repository;

import com.tma.gbst.model.Team;

/**
 * Created by Administrator on 5/19/15.
 */
public interface TeamRepository extends MyBaseRepository<Team, Integer> {
}
