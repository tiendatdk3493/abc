/**
 * Created by thuynghi on 4/22/2015.
 */
var trackingApp = angular.module('trackingApp', [
    'appDirectives',
    'appControllers'
]);


var directives = angular.module('appDirectives', []);
var controllers = angular.module('appControllers', []);